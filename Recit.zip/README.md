# Recit - Image Recognition
Recit is an image recognition android app that will recognize your images using TensorFlow Lite.
